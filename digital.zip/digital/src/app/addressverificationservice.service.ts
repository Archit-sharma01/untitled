import { HttpClient,HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError } from 'rxjs';
import { throwError } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AddressverificationserviceService {

  private finaldata = [];
  private apiurl = environment.baseUrl;

  constructor(private http:HttpClient) { }

  uploadSingleFile(url:any, postdata:any){
    return this.http.post<any>( url, postdata)
    .pipe(catchError(this.errorHandler))
 }

 callpostUrl(url:any,postdata:any){
    return this.http.post<any>(this.apiurl+""+url, postdata)
    .pipe(catchError(this.errorHandler))
 }
 
  callgetUrl(url:any){
    return this.http.get(this.apiurl+""+url);
 }

 callgetMapImg(url:any){
  return this.http.get(url);
 }
 
 LatLanData(url:any){
  return this.http.get(url);
}

 submitSignUp(url:any,postdata:any) {
    return this.http.post<any>(this.apiurl+""+url, postdata)
    .pipe(catchError(this.errorHandler))
 }

 errorHandler(error: HttpErrorResponse) {
  return throwError(error)
}
commaSeprateString(data:any){
   return data.replace(/,+/g, ', ');
}


}
